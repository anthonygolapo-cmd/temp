<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index() {
        return Post::all();
    }

    public function store(Request $request) {
        $post = Post::create([
            'title' => $request->title,
            'content' => $request->content,
            'user_id' => auth()->id()
        ]);
        return $post;
    }

    public function show(Post $post) {
        return $post;
    }

    public function update(Request $request, Post $post) {
        $post->update($request->all());
        return $post;
    }

    public function destroy(Post $post) {
    if (auth()->user()->role !== 'admin') {
        return response()->json(['error' => 'Unauthorized'], 403);
    }
    $post->delete();
    return response()->noContent();
}

}
