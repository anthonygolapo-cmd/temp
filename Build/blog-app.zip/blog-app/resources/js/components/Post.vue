import { createApp } from 'vue';
import Posts from './components/Posts.vue';

createApp({
    components: {
        Posts
    }
}).mount('#app');
